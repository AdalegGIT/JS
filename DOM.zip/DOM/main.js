//https://media.giphy.com/media/B0vFTrb0ZGDf2/giphy.gif  //happy
//https://media.giphy.com/media/p8Uw3hzdAE2dO/giphy.gif //rea


document.addEventListener('DOMContentLoaded',function(e){       
    let title = document.querySelector("h1");
    
    console.log(e)
    //console.log("hello::",title);

    // setInterval(function() {
    //     title.
    // }, 2000);

    setTimeout(function(){
        let image = document.querySelector("img");
        image.src = "https://media.giphy.com/media/B0vFTrb0ZGDf2/giphy.gif "
    },4000);

    let elemArray = document.querySelectorAll('.item');
    elemArray.forEach(function(e){
        e.innerText = "hi"
    })
})


